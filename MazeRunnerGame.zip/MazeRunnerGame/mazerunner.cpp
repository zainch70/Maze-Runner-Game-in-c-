#include <iostream>
#include <fstream>
using namespace std;

void copydata(char **old_dptr, char **new_dptr, int &newrow, int &newcol)
{
	for (int i = 0; i < newrow; i++)
	{
		for (int j = 0; j < newcol; j++)
		{
			new_dptr[i][j] = old_dptr[i][j];
		}
	}
}

char** regrowarray(char** old_dptr, int &newrow, int &newcol)
{
	//re-allocate memory with new size
	char **new_dptr = new char*[newrow + 1];
	for (int i = 0; i < newrow + 1; i++)
	{
		new_dptr[i] = new char[newcol + 1];
	}

	copydata(old_dptr, new_dptr, newrow, newcol);

	cout << "newrow =" << newrow + 1 << endl;
	cout << "newcol =" << newcol + 1 << endl;


	// deallocate memory
	for (int i = 0; i < newrow; i++)
	{
		delete[] old_dptr[i];
	}
	delete[] old_dptr;
	return new_dptr;

}

char** readfile(char **&o_dptr, int &row, int &col, ifstream &fin)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			fin >> o_dptr[i][j];
		}
	}

	cout << "Your Game Grid is Given below" << endl;
	cout << "\nYou can not move left and up on your first move\n";

	return o_dptr;

}


void easymode(char **&old_dptr, int &row, int &col, char name[])
{
	ifstream fin;
	ofstream fout(name);
	fin.open("easy.txt");

	if (!fin.is_open())
	{
		cout << "File for Easy Mode not found" << endl;
	}
	else
	{
		for (int i = 0; i<5; i++)
		{
			old_dptr = regrowarray(old_dptr, row, col);
			row++;
			col++;

		}

		char **o_dptr = readfile(old_dptr, row, col, fin);
		fin.close();


		char **t_dptr = new char*[row];
		for (int i = 0; i < row; i++)
		{
			t_dptr[i] = new char[col];
		}

		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				t_dptr[i][j] = o_dptr[i][j];
			}
			cout << endl;
		}


		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				fout << o_dptr[i][j];
			}
			fout << endl;
		}
		fout.close();


		while (1)
		{
			for (int i = 0; i < row; i++)
			{
				for (int j = 0; j < col; j++)
				{
					o_dptr[i][j] = t_dptr[i][j];
					cout << o_dptr[i][j];
				}
				cout << endl;
			}


			char movement;
			int lives = 3, moves = 11, m = 11;
			int size = moves;
			int i = 0, j = 0, p = 0;

			while (lives != 0)
			{
				moves = 11, p = 0;
				while (p<size)
				{
					ofstream ft(name);
					for (int i = 0; i<row; i++){
						for (int j = 0; j<col; j++){
							ft << o_dptr[i][j];
							ft << "\t";
						}ft << endl;
					}

					ft << "Moves =" << moves << endl << "Lives =" << lives;
					ft << endl << p << endl << i << endl << j;
					ft.close();


					cout << "You have moves : " << moves << endl;
					cout << "You have lives : " << lives << endl;
					cout << "Enter movement " << p + 1;
					cout << "\nEnter command : ";
					cin >> movement;
					moves--;
					m--;


					if (movement == 'U' || movement == 'u')
					{
						i--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}
					}

					else if (movement == 'D' || movement == 'd')
					{
						i++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;

						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'L' || movement == 'l')
					{
						j--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}

					else if (movement == 'R' || movement == 'r')
					{
						j++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'P' || movement == 'p')
					{

						cout << "GAME paused\n";
						cout << "Restart Your Game From Start" << endl;
						break;
					}
					else
					{
						cout << "Invalid input lost move.";
					}
					p++;

					if (lives == 0)
					{
						cout << "You have no Lives.";
						break;
					}
					if (j == 5)
					{
						cout << "You win the Game " << endl;
						break;
					}
					if (p == 11)
					{
						cout << "You Lost Your Moves Thats why you lose the game.." << endl;
					}
				}
				if (j == 5)
				{
					break;
				}
				if (movement == 'P' || movement == 'p')
				{
					break;
				}
			}
		}


	}

}

void mediummode(char **&old_dptr, int &row, int &col, char name[])
{
	ifstream fin;
	ofstream fout(name);
	fin.open("medium.txt");

	if (!fin.is_open())
	{
		cout << "File for Easy Mode not found" << endl;
	}
	else
	{
		for (int i = 0; i<7; i++)
		{
			old_dptr = regrowarray(old_dptr, row, col);
			row++;
			col++;

		}

		char **o_dptr = readfile(old_dptr, row, col, fin);
		fin.close();


		char **t_dptr = new char*[row];
		for (int i = 0; i < row; i++)
		{
			t_dptr[i] = new char[col];
		}

		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				t_dptr[i][j] = o_dptr[i][j];
			}
			cout << endl;
		}


		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				fout << o_dptr[i][j];
			}
			fout << endl;
		}
		fout.close();


		while (1)
		{
			for (int i = 0; i < row; i++)
			{
				for (int j = 0; j < col; j++)
				{
					o_dptr[i][j] = t_dptr[i][j];
					cout << o_dptr[i][j];
				}
				cout << endl;
			}


			char movement;
			int lives = 3, moves = 15, m = 15;
			int size = moves;
			int i = 0, j = 0, p = 0;

			while (lives != 0)
			{
				moves = 15, p = 0;
				while (p<size)
				{
					ofstream ft(name);
					for (int i = 0; i<row; i++){
						for (int j = 0; j<col; j++){
							ft << o_dptr[i][j];
							ft << "\t";
						}ft << endl;
					}

					ft << "Moves =" << moves << endl << "Lives =" << lives;
					ft << endl << p << endl << i << endl << j;
					ft.close();


					cout << "You have moves : " << moves << endl;
					cout << "You have lives : " << lives << endl;
					cout << "Enter movement " << p + 1;
					cout << "\nEnter command : ";
					cin >> movement;
					moves--;
					m--;


					if (movement == 'U' || movement == 'u')
					{
						i--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}
					}

					else if (movement == 'D' || movement == 'd')
					{
						i++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;

						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'L' || movement == 'l')
					{
						j--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}

					else if (movement == 'R' || movement == 'r')
					{
						j++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'P' || movement == 'p')
					{

						cout << "GAME paused\n";
						cout << "Restart Your Game From Start" << endl;
						break;
					}
					else
					{
						cout << "Invalid input lost move.";
					}
					p++;

					if (lives == 0)
					{
						cout << "You have no Lives.";
						break;
					}
					if (j == 7)
					{
						cout << "You win the Game " << endl;
						break;
					}
					if (p == 15)
					{
						cout << "You Lost Your Moves Thats why you lose the game.." << endl;
					}
				}
				if (j == 7)
				{
					break;
				}
				if (movement == 'P' || movement == 'p')
				{
					break;
				}
			}
		}


	}


}

void hardmode(char **&old_dptr, int &row, int &col, char name[])
{
	ifstream fin;
	ofstream fout(name);
	fin.open("hard.txt");

	if (!fin.is_open())
	{
		cout << "File for Easy Mode not found" << endl;
	}
	else
	{
		for (int i = 0; i<9; i++)
		{
			old_dptr = regrowarray(old_dptr, row, col);
			row++;
			col++;

		}

		char **o_dptr = readfile(old_dptr, row, col, fin);
		fin.close();


		char **t_dptr = new char*[row];
		for (int i = 0; i < row; i++)
		{
			t_dptr[i] = new char[col];
		}

		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				t_dptr[i][j] = o_dptr[i][j];
			}
			cout << endl;
		}


		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				fout << o_dptr[i][j];
			}
			fout << endl;
		}
		fout.close();


		while (1)
		{
			for (int i = 0; i < row; i++)
			{
				for (int j = 0; j < col; j++)
				{
					o_dptr[i][j] = t_dptr[i][j];
					cout << o_dptr[i][j];
				}
				cout << endl;
			}


			char movement;
			int lives = 3, moves = 19, m = 19;
			int size = moves;
			int i = 0, j = 0, p = 0;

			while (lives != 0)
			{
				moves = 19, p = 0;
				while (p<size)
				{
					ofstream ft(name);
					for (int i = 0; i<row; i++){
						for (int j = 0; j<col; j++){
							ft << o_dptr[i][j];
							ft << "\t";
						}ft << endl;
					}

					ft << "Moves =" << moves << endl << "Lives =" << lives;
					ft << endl << p << endl << i << endl << j;
					ft.close();


					cout << "You have moves : " << moves << endl;
					cout << "You have lives : " << lives << endl;
					cout << "Enter movement " << p + 1;
					cout << "\nEnter command : ";
					cin >> movement;
					moves--;
					m--;


					if (movement == 'U' || movement == 'u')
					{
						i--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}
					}

					else if (movement == 'D' || movement == 'd')
					{
						i++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;

						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'L' || movement == 'l')
					{
						j--;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}

					else if (movement == 'R' || movement == 'r')
					{
						j++;
						if (o_dptr[i][j] == '*')
						{
							o_dptr[i][j] = '1';
							for (int i = 0; i<row; i++)
							{
								for (int j = 0; j<col; j++)
								{
									cout << o_dptr[i][j] << "\t";
								}
								cout << endl;
							}
						}
						else if (o_dptr[i][j] == '+')
						{
							lives--;
							cout << "You have moves : " << m << endl;
							break;
						}
						else
						{
							o_dptr[i][j] = '|';

						}

					}
					else if (movement == 'P' || movement == 'p')
					{

						cout << "GAME paused\n";
						cout << "Restart Your Game From Start" << endl;
						break;
					}
					else
					{
						cout << "Invalid input lost move.";
					}
					p++;

					if (lives == 0)
					{
						cout << "You have no Lives.";
						break;
					}
					if (j == 9)
					{
						cout << "You win the Game " << endl;
						break;
					}
					if (p == 19)
					{
						cout << "You Lost Your Moves Thats why you lose the game.." << endl;
					}
				}
				if (j == 9)
				{
					break;
				}
				if (movement == 'P' || movement == 'p')
				{
					break;
				}
			}
		}

	}
}



int main()
{
	int mode = 0;
	char command = '\0';
	char name[20];

	cout << "Enter your name with .txt extension" << endl;
	cin.getline(name, 20);

	int row = 1, col = 1;
	char **old_dptr = new char*[row];

	for (int i = 0; i < row; i++)
	{
		old_dptr[i] = new char[col];
	}


	cout << "Do you want to play the game if yes then Press (Y) if No and you wants to End the Game then Press (N).." << endl;
	cin >> command;

	if (command == 'y' || command == 'Y')
	{
		int input = 0;

		do
		{
			cout << "Press 6 for instructions first then start playing.." << endl;
			cin >> input;

			if (input == 6)
			{
				cout << "Please read the instructions carefully..\n " << endl;
				cout << "Press U for up " << endl;
				cout << "Press D for down " << endl;
				cout << "Press L for left " << endl;
				cout << "Press R for right " << endl;
				cout << "If character * then path is free \n";
				cout << "If character | blockage in path \n";
				cout << "If character + monster creature in path \n";
				cout << "Press P for Paused And Restart Your Game\n " << endl;

				cout << "Now you will choice game modes\n " << endl;

				cout << "Enter The Mode of the Game.." << endl;
				cout << "For Easy Mode Press 1" << endl;
				cout << "For Medium Mode Press 2" << endl;
				cout << "For Hard Mode Press 3" << endl;

				do
				{
					cin >> mode;

					if (mode == 1)
					{
						easymode(old_dptr, row, col, name);

					}

					else if (mode == 2)
					{
						mediummode(old_dptr, row, col, name);
					}

					else if (mode == 3)
					{
						hardmode(old_dptr, row, col, name);
					}

					else
					{
						cout << "Please Press (1) (2) (3) only " << endl;
					}

				} while (1);

			}

			else
			{
				cout << "You input wrong instruction " << endl;
			}
		} while (input != 6);
	}

	else if (command == 'n' || command == 'N')
	{
		cout << "You dont want to play.. " << endl;
		return false;
	}
	else
	{
		cout << "Plz Press (Y) or (N) only.." << endl;
		return false;
	}




	system("pause");
	return 0;
}